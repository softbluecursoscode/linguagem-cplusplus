#pragma once

class DesenhoAnimado
{
public:
	DesenhoAnimado(int ano, const char *nome);
	int ano;
	char nome[30];
};