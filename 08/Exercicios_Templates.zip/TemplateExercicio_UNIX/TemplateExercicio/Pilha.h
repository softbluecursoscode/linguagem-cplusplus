#pragma once

#include <vector>
using namespace std;

template <class T> class Pilha
{
private:
	vector<T> estrutura;

public:
	Pilha();
	void push(T elemento);
	void pop();
	T top();
};

template <class T> Pilha<T>::Pilha()
{

}

template <class T> void Pilha<T>::push(T elemento)
{
	estrutura.insert(estrutura.end(), elemento);
}

template <class T> void Pilha<T>::pop()
{
	estrutura.erase(estrutura.end() - 1);
}

template <class T> T Pilha<T>::top()
{
	return estrutura.at(estrutura.size()-1);
}




