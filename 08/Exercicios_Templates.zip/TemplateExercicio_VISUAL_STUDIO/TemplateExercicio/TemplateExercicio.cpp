#include <iostream>
using namespace std;

#include "Pilha.h"

int main()
{
	cout << "\nResolucao Exercicio 1 (TEMPLATES)\n\n";

	Pilha<int> *pilhaInt;
	pilhaInt = new Pilha<int>();

	pilhaInt->push(1);
	pilhaInt->push(2);
	pilhaInt->push(3);

	cout << "Processando pilhaInt: " << pilhaInt->top() << endl;
	pilhaInt->pop();

	cout << "Processando pilhaInt: " << pilhaInt->top() << endl;
	pilhaInt->pop();

	cout << "Processando pilhaInt: " << pilhaInt->top() << endl;
	pilhaInt->pop();

	Pilha<char> *pilhaChar;
	pilhaChar = new Pilha<char>();

	pilhaChar->push(66);
	pilhaChar->push(67);
	pilhaChar->push(68);

	cout << "Processando pilhaChar: " << pilhaChar->top() << endl;
	pilhaChar->pop();

	cout << "Processando pilhaChar: " << pilhaChar->top() << endl;
	pilhaChar->pop();

	cout << "Processando pilhaChar: " << pilhaChar->top() << endl;
	pilhaChar->pop();
	
	cout << endl;
	system("PAUSE");
	return 0;
}
