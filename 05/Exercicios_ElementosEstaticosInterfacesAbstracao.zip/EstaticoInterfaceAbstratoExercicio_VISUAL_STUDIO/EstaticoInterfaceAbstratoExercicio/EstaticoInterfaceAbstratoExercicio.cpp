#include "ContaCorrente.h"
#include "ContaInvestimento.h"

#include <iostream>
using namespace std;

int main()
{
	cout << "\nResolucao Exercicio 1 (ELEMENTOS ESTATICOS, INTERFACES E ABSTRACAO)\n\n";

	ContaCorrente *cc = new ContaCorrente();
	cc->depositar(450);
	cc->sacar(100);
	cc->calcularSaldo();

	ContaInvestimento *ci = new ContaInvestimento();
	ci->depositar(450);
	ci->sacar(100);
	ci->calcularSaldo();

	cc->transferir(100, ci);
	cc->calcularSaldo();
	ci->calcularSaldo();

	cout << endl;
	system("PAUSE");
	return 0;
}