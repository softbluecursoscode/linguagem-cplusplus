#pragma once
#include "ContaBancaria.h"

class ContaInvestimento : public ContaBancaria
{
public:
	ContaInvestimento();
	void calcularSaldo();
};

