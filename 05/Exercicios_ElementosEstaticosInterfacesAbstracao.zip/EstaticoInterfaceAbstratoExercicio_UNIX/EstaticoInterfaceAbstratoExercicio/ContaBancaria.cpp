#include "ContaBancaria.h"

ContaBancaria::ContaBancaria()
{
	this->saldo = 0;
}

void ContaBancaria::depositar(double valor)
{
	this->saldo += valor;
}

void ContaBancaria::sacar(double valor)
{
	this->saldo -= valor;
}

void ContaBancaria::transferir(double valor, ContaBancaria *destino)
{
	this->sacar(valor);
	destino->depositar(valor);
}


