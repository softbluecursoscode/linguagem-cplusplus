#include "ContaInvestimento.h"
#include <iostream>
using namespace std;

ContaInvestimento::ContaInvestimento()
{
}

void ContaInvestimento::calcularSaldo()
{
	double saldoLiquido = saldo - (saldo / 100 * 5);
	cout << "Saldo liquido da conta investimento: " << saldoLiquido << endl;
}


