#pragma once
#include "ContaBancaria.h"

class ContaCorrente : public ContaBancaria
{
public:
	ContaCorrente();
	void calcularSaldo();
};

