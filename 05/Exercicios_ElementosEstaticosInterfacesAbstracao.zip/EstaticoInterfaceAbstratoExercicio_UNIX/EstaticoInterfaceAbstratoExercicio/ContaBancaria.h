#pragma once

class ContaBancaria
{
protected:
	double saldo;

public:
	ContaBancaria();
	void depositar(double valor);
	void sacar(double valor);
	void transferir(double valor, ContaBancaria *destino);
	virtual void calcularSaldo() = 0;
};

