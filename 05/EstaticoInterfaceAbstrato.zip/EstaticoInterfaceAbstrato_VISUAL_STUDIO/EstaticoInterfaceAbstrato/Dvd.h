#include "Digital.h"

class Dvd : public Digital
{
public:
	Dvd();
	Dvd(unsigned int codigo, char titulo[], unsigned int discos, unsigned int duracao, char legendas[], unsigned int regiao);
	~Dvd();
	
	void setLegendas(char legendas[]);
	char *getLegendas();

	void setRegiao(unsigned int regiao);
	unsigned int getRegiao();

	void showInfo();

private:
	char legendas[50];
	unsigned int regiao;
};
