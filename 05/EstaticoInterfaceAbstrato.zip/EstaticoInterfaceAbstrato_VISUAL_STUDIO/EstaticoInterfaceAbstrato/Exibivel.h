#pragma once

class Exibivel
{
public:
	//virtual void showInfo() = 0;
};