#pragma once

class Relogio
{
public:
	int horas;
	int minutos;
	int segundos;
	Relogio(int pHoras, int pMinutos, int pSegundos);
	void exibirHoras();
};

