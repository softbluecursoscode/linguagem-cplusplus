#pragma once

class Retangulo
{
public:
	int ladoA;
	int ladoB;
	Retangulo(int ladoA, int ladoB);
	void calcularArea();
};

