#include <iostream>
using namespace std;

#include "Livro.h"

int main()
{
	cout << "\nClasses e Objetos: Aula Pratica" << endl;

	// Criando um objeto com o construtor padrao

	Livro *meuLivro;
	meuLivro = new Livro();

	meuLivro->codigo = 1;
	strcpy(meuLivro->titulo, "A Vida de Andre");

	cout << endl;
	cout << "(meuLivro) Codigo: " << meuLivro->codigo << endl;
	cout << "(meuLivro) Titulo: " << meuLivro->titulo << endl;

	delete meuLivro;

	// Criando um objeto com o construtor customizado

	unsigned int codigo;
	char titulo[100];
	char editora[60];
	unsigned int paginas;
	char isbn[20];

	codigo = 2;
	strcpy(titulo, "A Vida de Andre (2)");
	strcpy(editora, "Softblue");
	paginas = 425;
	strcpy(isbn, "958-25-6547-568-5");

	Livro *livroAndre;
	livroAndre = new Livro(codigo, titulo, editora, paginas, isbn);

	cout << endl;
	cout << "(livroAndre) Codigo: " << livroAndre->codigo << endl;
	cout << "(livroAndre) Titulo: " << livroAndre->titulo << endl;
	cout << "(livroAndre) Editora: " << livroAndre->editora << endl;
	cout << "(livroAndre) Paginas: " << livroAndre->paginas << endl;
	cout << "(livroAndre) Isbn: " << livroAndre->isbn << endl;

	delete livroAndre;

	// Encerrando o aplicativo

	/* EXERCICIO: criar as demais classes e mostrar elas funcionando */

	cout << endl;
	return 0;
}