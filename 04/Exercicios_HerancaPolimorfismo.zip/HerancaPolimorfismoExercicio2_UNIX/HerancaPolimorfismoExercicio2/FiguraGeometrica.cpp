#include "FiguraGeometrica.h"
#include <string>

FiguraGeometrica::FiguraGeometrica(char nome[])
{
	strcpy(this->nome, nome);
}


