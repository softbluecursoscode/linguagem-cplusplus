#include <iostream>
using namespace std;

#include "Livro.h"
#include "Revista.h"
#include "Cd.h"
#include "Dvd.h"

int main()
{
	cout << "\nHeranca e Polimorfismo: Aula Pratica" << endl;

	// Variaveis diversas para utilizacao no codigo

	unsigned int codigo;
	char titulo[100];
	char editora[60];
	unsigned int paginas;
	char isbn[20];
	unsigned int ano;
	unsigned int mes;
	unsigned int discos;
	unsigned int duracao;
	unsigned int faixas;
	char legendas[50];
	unsigned int regiao;

	// Criando um objeto do tipo LIVRO

	codigo = 1;
	strcpy(titulo, "Senhor dos Aneis");
	strcpy(editora, "SoftBooks");
	paginas = 642;
	strcpy(isbn, "456-456-456-8");

	Livro *livro;
	livro = new Livro(codigo, titulo, editora, paginas, isbn);
	livro->showInfo();

	// Criando um objeto do tipo REVISTA
	
	codigo = 2;
	strcpy(titulo, "Code Magazine");
	strcpy(editora, "SoftMagazine");
	paginas = 75;
	ano = 2000;
	mes = 1;

	Revista *revista;
	revista = new Revista(codigo, titulo, editora, paginas, ano, mes);
	revista->showInfo();

	
	// Comando For
	
	Midia *variasMidias[2];
	variasMidias[0] = livro;
	variasMidias[1] = revista;

	cout << "\n\nComando For:";

	for (int i = 0; i < 2; i++)
	{
		variasMidias[i]->showInfo();
	}


	// Encerrando o aplicativo

	delete livro;
	delete revista;

	cout << endl;
	system("PAUSE");
	return 0;
}