#pragma once

class Midia
{
public:
	Midia();
	Midia(unsigned int codigo, char titulo[]);
	~Midia();

	void setCodigo(unsigned int codigo);
	unsigned int getCodigo();

	void setTitulo(char titulo[]);
	char *getTitulo();

	void showInfo();

private:
	unsigned int codigo;
	char titulo[100];
};
