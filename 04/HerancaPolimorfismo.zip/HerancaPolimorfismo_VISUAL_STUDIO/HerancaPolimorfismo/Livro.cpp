#include "Livro.h"
#include <string>

#include <iostream>
using namespace std;

Livro::Livro()
{

}

Livro::Livro(unsigned int codigo, char titulo[], char editora[], unsigned int paginas, char isbn[])
: Impressa(codigo, titulo, editora, paginas)
{
	this->setIsbn(isbn);
}

Livro::~Livro()
{

}


void Livro::setIsbn(char isbn[])
{
	strcpy(this->isbn, isbn);
}

char *Livro::getIsbn()
{
	return this->isbn;
}

void Livro::showInfo()
{
	cout << "\n\nLivro: ";
	cout << "\n codigo(" << this->getCodigo() << ") ";
	cout << "\n titulo(" << this->getTitulo() << ") ";
	cout << "\n editora(" << this->getEditora() << ") ";
	cout << "\n paginas(" << this->getPaginas() << ") ";
	cout << "\n isbn(" << this->getIsbn() << ") ";
}