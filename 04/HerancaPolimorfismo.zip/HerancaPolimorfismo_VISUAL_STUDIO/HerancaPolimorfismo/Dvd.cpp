#include "Dvd.h"
#include <string>

Dvd::Dvd()
{

}

Dvd::Dvd(unsigned int codigo, char titulo[], unsigned int discos, unsigned int duracao, char legendas[], unsigned int regiao)
{
	this->setCodigo(codigo);
	this->setTitulo(titulo);
	this->setDiscos(discos);
	this->setDuracao(duracao);
	this->setLegendas(legendas);
	this->setRegiao(regiao);
}

Dvd::~Dvd()
{

}

void Dvd::setCodigo(unsigned int codigo)
{
	this->codigo = codigo;
}

unsigned int Dvd::getCodigo()
{
	return codigo;
}

void Dvd::setTitulo(char titulo[])
{
	strncpy(this->titulo, titulo, sizeof(this->titulo));
}

char *Dvd::getTitulo()
{
	return this->titulo;
}

void Dvd::setDiscos(unsigned int discos)
{
	this->discos = discos;
}

unsigned int Dvd::getDiscos()
{
	return discos;
}

void Dvd::setDuracao(unsigned int duracao)
{
	this->duracao = duracao;
}

unsigned int Dvd::getDuracao()
{
	return duracao;
}

void Dvd::setLegendas(char legendas[])
{
	strncpy(this->legendas, legendas, sizeof(this->legendas));
}

char *Dvd::getLegendas()
{
	return legendas;
}

void Dvd::setRegiao(unsigned int regiao)
{
	this->regiao = regiao;
}

unsigned int Dvd::getRegiao()
{
	return regiao;
}


