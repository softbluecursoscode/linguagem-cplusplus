class Dvd
{
public:
	Dvd();
	Dvd(unsigned int codigo, char titulo[], unsigned int discos, unsigned int duracao, char legendas[], unsigned int regiao);
	~Dvd();

	void setCodigo(unsigned int codigo);
	unsigned int getCodigo();

	void setTitulo(char titulo[]);
	char *getTitulo();

	void setDiscos(unsigned int discos);
	unsigned int getDiscos();

	void setDuracao(unsigned int duracao);
	unsigned int getDuracao();

	void setLegendas(char legendas[]);
	char *getLegendas();

	void setRegiao(unsigned int regiao);
	unsigned int getRegiao();

private:
	unsigned int codigo;
	char titulo[100];
	unsigned int discos;
	unsigned int duracao;
	char legendas[50];
	unsigned int regiao;
};
