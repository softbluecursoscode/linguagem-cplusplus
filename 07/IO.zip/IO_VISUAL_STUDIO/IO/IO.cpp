#include <iostream>
using namespace std;

#include <iomanip>
#include "Produto.h"
#include <fstream>
#include <string>

int main()
{
	cout << "\nIO\n" << endl;

	int i = 15;
	double d = 28.0/3.0;
	float f = 29.0/3.0;

	// Sem formata��o

	cout << "Sem formata��o: " << endl;
	cout << i << endl;
	cout << d << endl;
	cout << f << endl;
	cout << endl;

	// setw

	cout << "setw: " << endl;
	cout << setw(6) << i << endl;
	cout << setw(6) << d << endl;
	cout << setw(6) << f << endl;
	cout << endl;

	cout << "Depois do uso do setw, sem seu uso: " << endl;
	cout << i << endl;
	cout << d << endl;
	cout << f << endl;
	cout << endl;

	// setfill

	cout << "setfill (e setw): " << endl;
	cout << setw(6) << setfill('0') << i << endl;
	cout << setw(6) << d << endl;
	cout << setw(6) << setfill('*') << f << endl;
	cout << endl;

	// setprecision

	cout << "Utilizando setprecision (e setw, setfill): " << endl;
	cout << setprecision(5) << setw(10) << i << endl;
	cout << setw(10) << d << endl;
	cout << setw(10) << f << endl;
	cout << setw(10) << 1.1 << endl;
	cout << endl;

	cout << "Utilizando fixed" << endl;
	cout << std::fixed;
	cout << setw(10) << i << endl;
	cout << setw(10) << d << endl;
	cout << setw(10) << f << endl;
	cout << setw(10) << 1.1 << endl;
	cout << endl;

	// setf

	cout.setf(std::ios::left);
	cout << setw(30) << "Meu texto" << endl;

	cout.setf(std::ios::right);
	cout << setw(30) << "Meu texto" << endl;

	// File IO: Gravando objetos

	Produto *p1 = new Produto(1, "Refrigerante");

	cout << "Produto p1 (pre gravacao): (" << p1->codigo << ") " << p1->descricao << endl;

	ofstream objectWriter;
	objectWriter.open("myobject.dat", ios::binary);
	objectWriter.write((char *)&p1, sizeof(p1));
	objectWriter.close();

	Produto *p2 = NULL;

	ifstream objectReader;
	objectReader.open("myobject.dat", ios::binary);
	objectReader.read((char *)&p2, sizeof(p2));
	objectReader.close();

	cout << "Produto p2 (pos gravacao): (" << p2->codigo << ") " << p2->descricao << endl;

	// File IO: Texto

	ofstream textWriter;
	textWriter.open("mytext.txt", ios::out);
	//textWriter.open("mytext.txt", ios::app);

	textWriter << "Exemplo de texto" << endl;
	textWriter << "sendo escrito" << endl;
	textWriter << "em um arquivo." << endl;
	textWriter.close();

	string line;

	ifstream textReader;
	textReader.open("mytext.txt", ios::in);

	if (textReader.is_open())
	{
		while (getline(textReader, line))
		{
			cout << line << endl;
		}
		textReader.close();
	}

	// Lendo caractere a caractere

	ifstream textReaderCharByChar;
	textReaderCharByChar.open("mytext.txt", ios::in);

	while (!textReaderCharByChar.eof())
	{
		char c = textReaderCharByChar.get();
		cout << "Char: " << c << endl;
	}

	textReaderCharByChar.close();

	// seekp, seekg 
	ifstream fileReader;
	fileReader.open("mytext.txt", ios::binary);

	ofstream fileWriter;
	fileWriter.open("mytextCOPY.txt", ios::binary);

	char buffer[3];
	int counter = 0;

	fileReader.seekg(0, fileReader.end);
	int fileLength = fileReader.tellg();
	int bufferLength;

	while (!fileReader.eof())
	{
		fileReader.seekg(counter * sizeof(buffer), ios::beg);
		// 0 * 3 = 0
		// 1 * 3 = 3
		// 2 * 3 = 6

		fileReader.read((char *)&buffer, sizeof(buffer));

		fileWriter.seekp(counter * sizeof(buffer), ios::beg);

		// Tratamento
		if (counter * sizeof(buffer)+3 > fileLength)
		{
			// ...tamanho do buffer - o que extrapolou
			bufferLength = 3 - ((counter * sizeof(buffer)) + 3 - fileLength);
		}
		else
		{
			bufferLength = sizeof(buffer);
		}


		fileWriter.write((char *)&buffer, bufferLength);

		counter++;
	}

	fileReader.close();
	fileWriter.close();



	cout << endl;
	system("PAUSE");
	return 0;
}