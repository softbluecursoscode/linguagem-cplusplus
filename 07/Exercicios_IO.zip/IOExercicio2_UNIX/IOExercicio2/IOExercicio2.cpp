#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main()
{
	std::cout << "\nResolucao Exercicio 2 (I/O)\n\n";

	int opcao;
	int subopcao;
	string nomeDoArquivo1;
	string nomeDoArquivo2;
	string buffer;
	ofstream textWriter;
	ifstream fileReader;
	ofstream fileWriter;
	char binaryBuffer[10];
	int counter = 0;
	int fileLength;
	int bufferLength;

	do
	{
		std::cout << "\nDigite 1 para CRIAR, 2 para COPIAR ou 3 para SAIR: ";
		cin >> opcao;

		switch (opcao)
		{
		case 1:
			std::cout << "\nInforme o nome do arquivo a ser criado: ";
			cin >> nomeDoArquivo1;

			textWriter.open(nomeDoArquivo1, ios::out);

			do
			{
				cout << "\nDigite 1 para gravar uma frase no arquivo, ou 0 para encerrar: ";
				cin >> subopcao;

				switch (subopcao)
				{
				case 1:
					cout << "\nDigite a frase a ser gravada: ";
					cin >> buffer;
					textWriter << buffer << endl;
					break;

				case 0:
					textWriter.close();
					break;

				default:
					std::cout << "\nOpcao invalida.";
					break;
				}
			} while (subopcao != 0);

			break;

		case 2:
			std::cout << "\nInforme o nome do arquivo origem, a ser copiado: ";
			cin >> nomeDoArquivo1;

			std::cout << "\nInforme o nome do arquivo destino, a ser criado: ";
			cin >> nomeDoArquivo2;

			fileReader.open(nomeDoArquivo1, ios::binary);
			fileWriter.open(nomeDoArquivo2, ios::binary);


			fileReader.seekg(0, fileReader.end);
			fileLength = fileReader.tellg();
			
			// Basicamente o mesmo c�digo de c�pia bin�ria de arquivo apresentado em aula
			while (!fileReader.eof())
			{
				fileReader.seekg(counter * sizeof(binaryBuffer), ios::beg);
				fileReader.read((char *)&binaryBuffer, sizeof(binaryBuffer));

				// Verifica se o final do buffer n�o passou do fim...
				if (counter * sizeof(binaryBuffer) + 10 > fileLength)
				{	
					// Tamanho 10 menos a diferen�a do FINAL do buffer
					bufferLength = 10 - ((counter * sizeof(binaryBuffer)) + 10 - fileLength);
				}
				else
				{
					bufferLength = 10;
				}

				fileWriter.seekp(counter * sizeof(binaryBuffer), ios::beg);
				fileWriter.write((char *)&binaryBuffer, bufferLength);

				counter++;
			}

			fileWriter.close();
			break;

		case 3:
			break;

		default:
			std::cout << "\nOpcao invalida.";
			break;
		}


	} while (opcao != 3);

	std::cout << endl;
	return 0;
}