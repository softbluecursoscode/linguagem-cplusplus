#include "SistemaLocadora.h"
#include <iostream>
#include <fstream>
using namespace std;

SistemaLocadora::SistemaLocadora()
{
	this->arquivoLer();
}

void SistemaLocadora::iniciar()
{
	int opcaoMenu;

	do
	{
		cout << "\n\n\n\nSistema de Locadora" << endl;
		cout << "\n1) Cadastrar midia;";
		cout << "\n2) Visualizar midias;";
		cout << "\n3) Sair;";
		cout << "\nDigite sua opcao: ";
		cin >> opcaoMenu;

		switch (opcaoMenu)
		{
		case 1:
			this->cadastrarMidia();
			break;
		case 2:
			this->visualizarMidias();
			break;
		case 3:
			// Sair do programa
			this->arquivoSalvar();
			break;
		default:
			cout << "\nOpcao invalida.";
			break;
		}
	} while (opcaoMenu != 3);
}

void SistemaLocadora::cadastrarMidia()
{
	int opcaoMenu;

	do
	{
		cout << "\n\n\n\nCADASTRAR MIDIA" << endl;
		cout << "\n1) Cadastrar Cd;";
		cout << "\n2) Cadastrar Dvd;";
		cout << "\n3) Cadastrar Revista;";
		cout << "\n4) Cadastrar Livro;";
		cout << "\n5) Retornar ao menu anterior;";

		cout << "\nDigite sua opcao: ";
		cin >> opcaoMenu;

		switch (opcaoMenu)
		{
		case 1:
			this->cadastrarCd();
			break;
		case 2:
			this->cadastrarDvd();
			break;
		case 3:
			this->cadastrarRevista();
			break;
		case 4:
			this->cadastrarLivro();
			break;
		case 5:
			// Retornar ao menu anterior
			break;
		default:
			cout << "\nOpcao invalida.";
			break;
		}
	} while (opcaoMenu != 5);
}

void SistemaLocadora::cadastrarCd()
{
	string entradaUsuarioString;
	int entradaUsuarioInt;

	Cd *cd = new Cd();

	cout << "\nDigite o codigo do Cd: ";
	cin >> entradaUsuarioInt;
	cd->setCodigo(entradaUsuarioInt);

	cout << "\nDigite o titulo do Cd: ";
	cin.get();
	getline(cin, entradaUsuarioString);
	cd->setTitulo(entradaUsuarioString);

	cout << "\nDigite o total de discos do Cd: ";
	cin >> entradaUsuarioInt;
	cd->setDiscos(entradaUsuarioInt);

	cout << "\nDigite a duracao do Cd: ";
	cin >> entradaUsuarioInt;
	cd->setDuracao(entradaUsuarioInt);

	cout << "\nDigite o total de faixas do Cd: ";
	cin >> entradaUsuarioInt;
	cd->setFaixas(entradaUsuarioInt);

	cds.insert(cds.begin(), *cd);
}

void SistemaLocadora::cadastrarDvd()
{
	string entradaUsuarioString;
	int entradaUsuarioInt;

	Dvd *dvd = new Dvd();

	cout << "\nDigite o codigo do Dvd: ";
	cin >> entradaUsuarioInt;
	dvd->setCodigo(entradaUsuarioInt);

	cout << "\nDigite o titulo do Dvd: ";
	cin.get();
	getline(cin, entradaUsuarioString);
	dvd->setTitulo(entradaUsuarioString);

	cout << "\nDigite o total de discos do Dvd: ";
	cin >> entradaUsuarioInt;
	dvd->setDiscos(entradaUsuarioInt);

	cout << "\nDigite a duracao do Dvd: ";
	cin >> entradaUsuarioInt;
	dvd->setDuracao(entradaUsuarioInt);

	cout << "\nDigite as legendas do Dvd: ";
	cin.get();
	getline(cin, entradaUsuarioString);
	dvd->setLegendas(entradaUsuarioString);

	cout << "\nDigite a regiao do Dvd: ";
	cin >> entradaUsuarioInt;
	dvd->setRegiao(entradaUsuarioInt);

	dvds.insert(dvds.begin(), *dvd);
}

void SistemaLocadora::cadastrarRevista()
{
	string entradaUsuarioString;
	int entradaUsuarioInt;

	Revista *revista = new Revista();

	cout << "\nDigite o codigo do Revista: ";
	cin >> entradaUsuarioInt;
	revista->setCodigo(entradaUsuarioInt);

	cout << "\nDigite o titulo do Revista: ";
	cin.get();
	getline(cin, entradaUsuarioString);
	revista->setTitulo(entradaUsuarioString);

	cout << "\nDigite a editora do Revista: ";
	getline(cin, entradaUsuarioString);
	revista->setEditora(entradaUsuarioString);

	cout << "\nDigite o total de paginas do Revista: ";
	cin >> entradaUsuarioInt;
	revista->setPaginas(entradaUsuarioInt);

	cout << "\nDigite o ano do Revista: ";
	cin >> entradaUsuarioInt;
	revista->setAno(entradaUsuarioInt);

	cout << "\nDigite o mes do Revista: ";
	cin >> entradaUsuarioInt;
	revista->setMes(entradaUsuarioInt);

	revistas.insert(revistas.begin(), *revista);
}

void SistemaLocadora::cadastrarLivro()
{
	string entradaUsuarioString;
	int entradaUsuarioInt;

	Livro *livro = new Livro();

	cout << "\nDigite o codigo do Livro: ";
	cin >> entradaUsuarioInt;
	livro->setCodigo(entradaUsuarioInt);

	cout << "\nDigite o titulo do Livro: ";
	cin.get();
	getline(cin, entradaUsuarioString);
	livro->setTitulo(entradaUsuarioString);

	cout << "\nDigite a editora do Livro: ";
	getline(cin, entradaUsuarioString);
	livro->setEditora(entradaUsuarioString);

	cout << "\nDigite o total de paginas do Livro: ";
	cin >> entradaUsuarioInt;
	livro->setPaginas(entradaUsuarioInt);

	cout << "\nDigite o ISBN do Livro: ";
	cin.get();
	getline(cin, entradaUsuarioString);
	livro->setIsbn(entradaUsuarioString);

	livros.insert(livros.begin(), *livro);
}

void SistemaLocadora::visualizarMidias()
{
	int opcaoMenu;

	do
	{
		cout << "\n\n\n\VISUALIZAR MIDIAS" << endl;
		cout << "\n1) Visualizar Cds;";
		cout << "\n2) Visualizar Dvds;";
		cout << "\n3) Visualizar Revistas;";
		cout << "\n4) Visualizar Livros;";
		cout << "\n5) Retornar ao menu anterior;";

		cout << "\nDigite sua opcao: ";
		cin >> opcaoMenu;

		switch (opcaoMenu)
		{
		case 1:
			this->visualizarCds();
			break;
		case 2:
			this->visualizarDvds();
			break;
		case 3:
			this->visualizarRevistas();
			break;
		case 4:
			this->visualizarLivros();
			break;
		case 5:
			// Retornar ao menu anterior
			break;
		default:
			cout << "\nOpcao invalida.";
			break;
		}
	} while (opcaoMenu != 5);
}

void SistemaLocadora::visualizarCds()
{
	Cd *cd;
	for (int i = 0; i<cds.size(); i++)
	{
		cd = &cds.at(i);
		cd->showInfo();
	}
}

void SistemaLocadora::visualizarDvds()
{
	Dvd *dvd;
	for (int i = 0; i<dvds.size(); i++)
	{
		dvd = &dvds.at(i);
		dvd->showInfo();
	}
}

void SistemaLocadora::visualizarRevistas()
{
	Revista *revista;
	for (int i = 0; i<revistas.size(); i++)
	{
		revista = &revistas.at(i);
		revista->showInfo();
	}
}

void SistemaLocadora::visualizarLivros()
{
	Livro *livro;
	for (int i = 0; i<livros.size(); i++)
	{
		livro = &livros.at(i);
		livro->showInfo();
	}
}

void SistemaLocadora::arquivoSalvar()
{
	ofstream fileSave;
	
	// === Grava��o dos cds ===================================================

	if (cds.size() > 0)
	{
		fileSave.open(filenameCds, ios::binary);

		int cdsSize = (int)cds.size();
		fileSave.write((char*)&cdsSize, sizeof(unsigned int));

		Cd *cd = NULL;
		for (int i = 0; i < cds.size(); i++)
		{
			cd = &cds.at(i);

			int codigo = (int)cd->getCodigo();
			fileSave.write((char *)&codigo, sizeof(unsigned int));

			string titulo = cd->getTitulo();
			fileSave.write((char *)titulo.c_str(), 100 * sizeof(char));

			int discos = (int)cd->getDiscos();
			fileSave.write((char *)&discos, sizeof(unsigned int));

			int duracao = (int)cd->getDuracao();
			fileSave.write((char *)&duracao, sizeof(unsigned int));

			int faixas = (int)cd->getFaixas();
			fileSave.write((char *)&faixas, sizeof(unsigned int));
		}

		fileSave.close();
	}

	// === Grava��o dos dvds ==================================================

	if (dvds.size() > 0)
	{
		fileSave.open(filenameDvds, ios::binary);

		int dvdsSize = (int)dvds.size();
		fileSave.write((char*)&dvdsSize, sizeof(unsigned int));

		Dvd *dvd = NULL;
		for (int i = 0; i < dvds.size(); i++)
		{
			dvd = &dvds.at(i);

			int codigo = (int)dvd->getCodigo();
			fileSave.write((char *)&codigo, sizeof(unsigned int));

			string titulo = dvd->getTitulo();
			fileSave.write((char *)titulo.c_str(), 100 * sizeof(char));

			int discos = (int)dvd->getDiscos();
			fileSave.write((char *)&discos, sizeof(unsigned int));

			int duracao = (int)dvd->getDuracao();
			fileSave.write((char *)&duracao, sizeof(unsigned int));

			string legendas = dvd->getLegendas();
			fileSave.write((char *)legendas.c_str(), 100 * sizeof(char));

			int regiao = (int)dvd->getRegiao();
			fileSave.write((char *)&regiao, sizeof(unsigned int));
		}

		fileSave.close();
	}

	// === Grava��o dos livros ================================================

	if (livros.size() > 0)
	{
		fileSave.open(filenameLivros, ios::binary);

		int livrosSize = (int)livros.size();
		fileSave.write((char*)&livrosSize, sizeof(unsigned int));

		Livro *livro = NULL;
		for (int i = 0; i < livros.size(); i++)
		{
			livro = &livros.at(i);

			int codigo = (int)livro->getCodigo();
			fileSave.write((char *)&codigo, sizeof(unsigned int));

			string titulo = livro->getTitulo();
			fileSave.write((char *)titulo.c_str(), 100 * sizeof(char));

			string editora = livro->getEditora();
			fileSave.write((char *)editora.c_str(), 100 * sizeof(char));

			int paginas = (int)livro->getPaginas();
			fileSave.write((char *)&paginas, sizeof(unsigned int));

			string isbn = livro->getIsbn();
			fileSave.write((char *)isbn.c_str(), 100 * sizeof(char));
		}

		fileSave.close();
	}

	// === Grava��o dos revistas ==============================================

	if (revistas.size() > 0)
	{
		fileSave.open(filenameRevistas, ios::binary);

		int revistasSize = (int)revistas.size();
		fileSave.write((char*)&revistasSize, sizeof(unsigned int));

		Revista *revista = NULL;
		for (int i = 0; i < revistas.size(); i++)
		{
			revista = &revistas.at(i);

			int codigo = (int)revista->getCodigo();
			fileSave.write((char *)&codigo, sizeof(unsigned int));

			string titulo = revista->getTitulo();
			fileSave.write((char *)titulo.c_str(), 100 * sizeof(char));

			string editora = revista->getEditora();
			fileSave.write((char *)editora.c_str(), 100 * sizeof(char));

			int paginas = (int)revista->getPaginas();
			fileSave.write((char *)&paginas, sizeof(unsigned int));

			int ano = (int)revista->getAno();
			fileSave.write((char *)&ano, sizeof(unsigned int));

			int mes = (int)revista->getMes();
			fileSave.write((char *)&mes, sizeof(unsigned int));
		}

		fileSave.close();
	}

	// Limpando a mem�ria

	for (int i = 0; i < cds.size(); i++)
		delete(&cds.at(i));

	for (int i = 0; i < dvds.size(); i++)
		delete(&dvds.at(i));

	for (int i = 0; i < livros.size(); i++)
		delete(&livros.at(i));

	for (int i = 0; i < revistas.size(); i++)
		delete(&revistas.at(i));
}

void SistemaLocadora::arquivoLer()
{
	ifstream fileOpen;

	// === Leitura dos cds ====================================================

	fileOpen.open(filenameCds, ios::binary);

	if (fileOpen.is_open())
	{
		int cdsSize;
		fileOpen.read((char*)&cdsSize, sizeof(unsigned int));

		Cd *cd = NULL;
		for (int i = 0; i < cdsSize; i++)
		{
			cd = new Cd();

			int codigo;
			fileOpen.read((char *)&codigo, sizeof(unsigned int));
			cd->setCodigo(codigo);

			char bufferTitulo[100];
			fileOpen.read((char *)&bufferTitulo, 100 * sizeof(char));
			string titulo(bufferTitulo);
			cd->setTitulo(titulo);

			int discos;
			fileOpen.read((char *)&discos, sizeof(unsigned int));
			cd->setDiscos(discos);

			int duracao;
			fileOpen.read((char *)&duracao, sizeof(unsigned int));
			cd->setDuracao(duracao);

			int faixas;
			fileOpen.read((char *)&faixas, sizeof(unsigned int));
			cd->setFaixas(faixas);

			cds.insert(cds.begin(), *cd);
		}

		fileOpen.close();
	}

	// === Leitura dos dvds ====================================================

	fileOpen.open(filenameDvds, ios::binary);

	if (fileOpen.is_open())
	{

		int dvdsSize;
		fileOpen.read((char*)&dvdsSize, sizeof(unsigned int));

		Dvd *dvd = NULL;
		for (int i = 0; i < dvdsSize; i++)
		{
			dvd = new Dvd();

			int codigo;
			fileOpen.read((char *)&codigo, sizeof(unsigned int));
			dvd->setCodigo(codigo);

			char bufferTitulo[100];
			fileOpen.read((char *)&bufferTitulo, 100 * sizeof(char));
			string titulo(bufferTitulo);
			dvd->setTitulo(titulo);

			int discos;
			fileOpen.read((char *)&discos, sizeof(unsigned int));
			dvd->setDiscos(discos);

			int duracao;
			fileOpen.read((char *)&duracao, sizeof(unsigned int));
			dvd->setDuracao(duracao);

			char bufferLegendas[100];
			fileOpen.read((char *)&bufferLegendas, 100 * sizeof(char));
			string legendas(bufferLegendas);
			dvd->setLegendas(legendas);

			int regiao;
			fileOpen.read((char *)&regiao, sizeof(unsigned int));
			dvd->setRegiao(regiao);

			dvds.insert(dvds.begin(), *dvd);
		}

		fileOpen.close();
	}

	// === Leitura dos livros =================================================

	fileOpen.open(filenameLivros, ios::binary);

	if (fileOpen.is_open())
	{

		int livrosSize;
		fileOpen.read((char*)&livrosSize, sizeof(unsigned int));

		Livro *livro = NULL;
		for (int i = 0; i < livrosSize; i++)
		{
			livro = new Livro();

			int codigo;
			fileOpen.read((char *)&codigo, sizeof(unsigned int));
			livro->setCodigo(codigo);

			char bufferTitulo[100];
			fileOpen.read((char *)&bufferTitulo, 100 * sizeof(char));
			string titulo(bufferTitulo);
			livro->setTitulo(titulo);

			char bufferEditora[100];
			fileOpen.read((char *)&bufferEditora, 100 * sizeof(char));
			string editora(bufferEditora);
			livro->setEditora(editora);

			int paginas;
			fileOpen.read((char *)&paginas, sizeof(unsigned int));
			livro->setPaginas(paginas);

			char bufferIsbn[100];
			fileOpen.read((char *)&bufferIsbn, 100 * sizeof(char));
			string isbn(bufferIsbn);
			livro->setIsbn(isbn);

			livros.insert(livros.begin(), *livro);
		}

		fileOpen.close();
	}

	// === Leitura dos revistas ===============================================

	fileOpen.open(filenameRevistas, ios::binary);

	if (fileOpen.is_open())
	{

		int revistasSize;
		fileOpen.read((char*)&revistasSize, sizeof(unsigned int));

		Revista *revista = NULL;
		for (int i = 0; i < revistasSize; i++)
		{
			revista = new Revista();

			int codigo;
			fileOpen.read((char *)&codigo, sizeof(unsigned int));
			revista->setCodigo(codigo);

			char bufferTitulo[100];
			fileOpen.read((char *)&bufferTitulo, 100 * sizeof(char));
			string titulo(bufferTitulo);
			revista->setTitulo(titulo);

			char bufferEditora[100];
			fileOpen.read((char *)&bufferEditora, 100 * sizeof(char));
			string editora(bufferEditora);
			revista->setEditora(editora);

			int paginas;
			fileOpen.read((char *)&paginas, sizeof(unsigned int));
			revista->setPaginas(paginas);

			int ano;
			fileOpen.read((char *)&ano, sizeof(unsigned int));
			revista->setAno(ano);

			int mes;
			fileOpen.read((char *)&mes, sizeof(unsigned int));
			revista->setMes(mes);

			revistas.insert(revistas.begin(), *revista);
		}

		fileOpen.close();
	}
}
