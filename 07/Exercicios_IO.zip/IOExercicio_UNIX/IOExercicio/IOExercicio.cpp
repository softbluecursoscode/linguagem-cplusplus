#include <iostream>
using namespace std;

#include "SistemaLocadora.h"

int main()
{
	cout << "\nResolucao Exercicio 1 (I/O)\n\n";

	SistemaLocadora *sl = new SistemaLocadora();
	sl->iniciar();

	cout << endl;
	return 0;
}

