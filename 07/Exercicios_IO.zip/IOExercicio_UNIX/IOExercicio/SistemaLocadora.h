#pragma once

#include "Livro.h"
#include "Revista.h"
#include "Cd.h"
#include "Dvd.h"

#include <vector>
using namespace std;

class SistemaLocadora
{
private:
	vector<Cd> cds;
	vector<Dvd> dvds;
	vector<Livro> livros;
	vector<Revista> revistas;
	string filenameCds = "arquivoDeCds.dat";
	string filenameDvds = "arquivoDeDvds.dat";
	string filenameLivros = "arquivoDeLivros.dat";
	string filenameRevistas = "arquivoDeRevistas.dat";

public:
	SistemaLocadora();

	void iniciar();
		void cadastrarMidia();
			void cadastrarCd();
			void cadastrarDvd();
			void cadastrarRevista();
			void cadastrarLivro();
		void visualizarMidias();
			void visualizarCds();
			void visualizarDvds();
			void visualizarRevistas();
			void visualizarLivros();

	void arquivoSalvar();
	void arquivoLer();
};

