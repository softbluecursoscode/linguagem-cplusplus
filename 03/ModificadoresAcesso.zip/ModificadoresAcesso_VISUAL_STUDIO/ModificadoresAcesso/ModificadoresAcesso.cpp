#include <iostream>
using namespace std;

#include "Livro.h"
#include "Revista.h"
#include "Cd.h"
#include "Dvd.h"

int main()
{
	cout << "\nEncapsulamento e Modificadores de Acesso: Aula Pratica" << endl;

	// Variaveis diversas para utilizacao no codigo

	unsigned int codigo;
	char titulo[100];
	char editora[60];
	unsigned int paginas;
	char isbn[20];
	unsigned int ano;
	unsigned int mes;
	unsigned int discos;
	unsigned int duracao;
	unsigned int faixas;
	char legendas[50];
	unsigned int regiao;

	// Criando um objeto do tipo LIVRO

	codigo = 1;
	strcpy(titulo, "Senhor dos Aneis");
	strcpy(editora, "SoftBooks");
	paginas = 642;
	strcpy(isbn, "456-456-456-8");

	Livro *livro;
	livro = new Livro(codigo, titulo, editora, paginas, isbn);
	
	cout << endl;
	cout << "(livro) Codigo: " << livro->getCodigo() << endl;
	cout << "(livro) Titulo: " << livro->getTitulo() << endl;
	cout << "(livro) Editora: " << livro->getEditora() << endl;
	cout << "(livro) Paginas: " << livro->getPaginas() << endl;
	cout << "(livro) Isbn: " << livro->getIsbn() << endl;
	
	delete livro;

	// Encerrando o aplicativo

	/* EXERCICIO: tornar os atributos das classes PRIVATE e incluir os getters e setters PUBLICOS */

	cout << endl;
	system("PAUSE");
	return 0;
}