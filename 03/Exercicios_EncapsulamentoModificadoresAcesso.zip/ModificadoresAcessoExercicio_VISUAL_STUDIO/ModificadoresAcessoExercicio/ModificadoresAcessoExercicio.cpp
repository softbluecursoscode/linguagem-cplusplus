#include <iostream>
using namespace std;

#include "Livro.h"
#include "Revista.h"
#include "Cd.h"
#include "Dvd.h"

int main()
{
	cout << "\nEncapsulamento e Modificadores de Acesso: Exercicio" << endl;

	// Variaveis diversas para utilizacao no codigo

	unsigned int codigo;
	char titulo[100];
	char editora[60];
	unsigned int paginas;
	char isbn[20];
	unsigned int ano;
	unsigned int mes;
	unsigned int discos;
	unsigned int duracao;
	unsigned int faixas;
	char legendas[50];
	unsigned int regiao;

	// Criando um objeto do tipo LIVRO

	codigo = 1;
	strcpy(titulo, "Senhor dos Aneis");
	strcpy(editora, "SoftBooks");
	paginas = 642;
	strcpy(isbn, "456-456-456-8");

	Livro *livro;
	livro = new Livro(codigo, titulo, editora, paginas, isbn);

	cout << endl;
	cout << "(livro) Codigo: " << livro->getCodigo() << endl;
	cout << "(livro) Titulo: " << livro->getTitulo() << endl;
	cout << "(livro) Editora: " << livro->getEditora() << endl;
	cout << "(livro) Paginas: " << livro->getPaginas() << endl;
	cout << "(livro) Isbn: " << livro->getIsbn() << endl;

	delete livro;

	// Criando um objeto do tipo REVISTA

	codigo = 2;
	strcpy(titulo, "BlueWeek");
	strcpy(editora, "SoftBooks");
	paginas = 60;
	strcpy(isbn, "226-336-444-5");
	ano = 2000;
	mes = 1;

	Revista *revista;
	revista = new Revista(codigo, titulo, editora, paginas, ano, mes);

	cout << endl;
	cout << "(revista) Codigo: " << revista->getCodigo() << endl;
	cout << "(revista) Titulo: " << revista->getTitulo() << endl;
	cout << "(revista) Editora: " << revista->getEditora() << endl;
	cout << "(revista) Paginas: " << revista->getPaginas() << endl;
	cout << "(revista) Ano: " << revista->getAno() << endl;
	cout << "(revista) Mes: " << revista->getMes() << endl;

	delete revista;

	// Criando um objeto do tipo CD

	codigo = 3;
	strcpy(titulo, "Metalizado - Gray Album");
	discos = 1;
	duracao = 57;
	faixas = 12;

	Cd *cd;
	cd = new Cd(codigo, titulo, discos, duracao, faixas);

	cout << endl;
	cout << "(cd) Codigo: " << cd->getCodigo() << endl;
	cout << "(cd) Titulo: " << cd->getTitulo() << endl;
	cout << "(cd) Discos: " << cd->getDiscos() << endl;
	cout << "(cd) Duracao: " << cd->getDuracao() << endl;
	cout << "(cd) Faixas: " << cd->getFaixas() << endl;

	delete cd;

	// Criando um objeto do tipo DVD

	codigo = 4;
	strcpy(titulo, "Titanic");
	discos = 1;
	duracao = 112;
	strcpy(legendas, "PT, EN");
	regiao = 4;

	Dvd *dvd;
	dvd = new Dvd(codigo, titulo, discos, duracao, legendas, regiao);

	cout << endl;
	cout << "(dvd) Codigo: " << dvd->getCodigo() << endl;
	cout << "(dvd) Titulo: " << dvd->getTitulo() << endl;
	cout << "(dvd) Discos: " << dvd->getDiscos() << endl;
	cout << "(dvd) Duracao: " << dvd->getDuracao() << endl;
	cout << "(dvd) Legendas: " << dvd->getLegendas() << endl;
	cout << "(dvd) Regiao: " << dvd->getRegiao() << endl;

	delete dvd;

	// Encerrando o aplicativo

	cout << endl;
	system("PAUSE");
	return 0;
}