#pragma once

class Retangulo
{
private:
	int ladoA;
	int ladoB;
public:
	Retangulo(int ladoA, int ladoB);
	void calcularArea();
};