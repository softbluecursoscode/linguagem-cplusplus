#pragma once

class Relogio
{
private:
	int horas;
	int minutos;
	int segundos;
public:
	Relogio(int pHoras, int pMinutos, int pSegundos);
	void exibirHoras();
};

