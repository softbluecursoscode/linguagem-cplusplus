#include "Relogio.h"
#include "Retangulo.h"
#include <iostream>
using namespace std;

int main()
{
	cout << "\nResolucao Exercicio 2 (ENCAPSULAMENTO E MODIFICADORES DE ACESSO)\n\n";

	Retangulo *retangulo = new Retangulo(4, 5);
	retangulo->calcularArea();

	Relogio *relogio = new Relogio(12, 03, 16);
	relogio->exibirHoras();

	// As linhas a seguir n�o compilam se as classes estiverem corretamente encapsuladas

	// cout << "Lados do retangulo: " << retangulo->ladoA << " x " << retangulo->ladoB;
	// cout << "Informacoes do relogio: " << relogio->horas << ":" << relogio->minutos << ":" << relogio->segundos

	cout << endl;
	return 0;
}

