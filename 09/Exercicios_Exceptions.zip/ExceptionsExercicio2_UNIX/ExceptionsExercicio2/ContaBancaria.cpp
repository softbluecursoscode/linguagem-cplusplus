#include "ContaBancaria.h"
#include "SaldoInsuficienteException.h"
#include "ValorInvalidoException.h"

ContaBancaria::ContaBancaria()
{
	this->saldo = 0;
}

void ContaBancaria::depositar(double valor) throw (ValorInvalidoException)
{
	if (valor < 0)
		throw ValorInvalidoException(valor);

	this->saldo += valor;
}

void ContaBancaria::sacar(double valor) throw (ValorInvalidoException, SaldoInsuficienteException)
{
	if (valor < 0)
		throw ValorInvalidoException(valor);

	if (valor > this->saldo)
		throw SaldoInsuficienteException(this->saldo);

	this->saldo -= valor;
}

void ContaBancaria::transferir(double valor, ContaBancaria *destino) throw (ValorInvalidoException)
{
	if (valor < 0)
		throw ValorInvalidoException(valor);

	this->sacar(valor);
	destino->depositar(valor);
}


