#include "ValorInvalidoException.h"
#include <iostream>
using namespace std;

ValorInvalidoException::ValorInvalidoException(double valor)
{
	this->valor = valor;
}

void ValorInvalidoException::exceptionMessage()
{
	cout << "Valor utilizado invalido. Valor tentado: " << this->valor << endl;
}
