#include "ContaCorrente.h"
#include <iostream>
using namespace std;

ContaCorrente::ContaCorrente()
{
}

void ContaCorrente::calcularSaldo()
{
	double saldoLiquido = saldo - (saldo / 100 * 10);
	cout << "Saldo liquido da conta corrente: " << saldoLiquido << endl;
}
