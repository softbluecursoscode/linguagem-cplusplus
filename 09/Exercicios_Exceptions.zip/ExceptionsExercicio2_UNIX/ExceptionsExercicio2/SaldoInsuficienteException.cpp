#include "SaldoInsuficienteException.h"
#include <iostream>
using namespace std;

SaldoInsuficienteException::SaldoInsuficienteException(double saldo)
{
	this->saldo = saldo;
}

void SaldoInsuficienteException::exceptionMessage()
{
	cout << "Valor utilizado superior ao saldo. Saldo atual: " << this->saldo << endl;
}

