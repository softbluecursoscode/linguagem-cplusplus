#include "ContaCorrente.h"
#include "ContaInvestimento.h"
#include "SaldoInsuficienteException.h"
#include "ValorInvalidoException.h"
#include <iostream>
using namespace std;

int main()
{
	cout << "\nResolucao Exercicio 2 (EXCEPTIONS)\n\n";

	try
	{
		ContaCorrente *cc = new ContaCorrente();
		cc->depositar(450);

		// Para lan�ar uma SaldoInsuficienteException
		cc->sacar(500);

		// Para lan�ar um ValorInvalidoException
		// Para visualiz�-lo � necess�rio comentar a linha que lan�a a exception anterior
		cc->depositar(-15);
	}
	catch (SaldoInsuficienteException &sie)
	{
		sie.exceptionMessage();
	}
	catch (ValorInvalidoException &vie)
	{
		vie.exceptionMessage();
	}

	cout << endl;
	return 0;
}