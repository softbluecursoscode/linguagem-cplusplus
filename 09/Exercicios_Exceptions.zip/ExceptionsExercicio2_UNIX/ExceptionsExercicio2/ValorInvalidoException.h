#pragma once
#include <string>
using namespace std;

class ValorInvalidoException
{
private:
	double valor;

public:
	ValorInvalidoException(double valor);
	void exceptionMessage();
};

