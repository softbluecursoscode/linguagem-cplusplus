#pragma once
#include <string>
using namespace std;

class SaldoInsuficienteException
{
private:
	double saldo;

public:
	SaldoInsuficienteException(double saldo);
	void exceptionMessage();
};

