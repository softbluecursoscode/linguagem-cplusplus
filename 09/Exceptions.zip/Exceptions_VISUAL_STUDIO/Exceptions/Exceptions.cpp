#include <iostream>
using namespace std;

#include "MinhaException.h"

// Manual dos erros
const int FILE_READER_FAILED_TO_OPEN = -1;
const int FILE_READER_FAILED_TO_GET_DATA = -2;
const int FILE_READER_FAILED_TO_CLOSE = -3;

int FileReaderOpen(const char *filename)
{
	bool success = true;

	if (success)
		return 0;
	else
		return FILE_READER_FAILED_TO_OPEN;
}

int FileReaderGetData(char *data)
{
	bool success = true;

	if(success)
	{
		strcpy(data, "58 25 36 56 89 52");
		return 0;
	}
	else
		return FILE_READER_FAILED_TO_GET_DATA;
}

int FileReaderClose()
{
	bool success = true;

	if (success)
		return 0;
	else
		return FILE_READER_FAILED_TO_CLOSE;
}

void EX_FileReaderOpen(const char *filename) throw (int)
{
	bool success = true;

	if (success == false)
		throw(FILE_READER_FAILED_TO_OPEN);
}

void EX_FileReaderGetData(char *data) throw (int)
{
	bool success = true;

	if (success)
	{
		strcpy(data, "58 25 36 56 89 52");
	}
	else
		throw(FILE_READER_FAILED_TO_GET_DATA);
}

void EX_FileReaderClose() throw (int)
{
	bool success = true;

	if (success == false)
		throw(FILE_READER_FAILED_TO_CLOSE);
}

void EX_DiferentThrowSample() throw (int, float, char, double)
{
	//throw((int)5);
	//throw((float)5);
	//throw((char)70);
	//throw((double)5);
	cout << "Funcao DiferentThrowSample ok" << endl;

	return;
}

void EX_FuncaoLancaExceptionClass() throw(MinhaException)
{
	throw(MinhaException(47, 8888, "softblue.com.br"));

	return;
}

int main()
{
	cout << "\nExceptions\n" << endl;

	char data[20];

	// Realizando as a��es sem nenhum tipo de tratamento
	
	strcpy(data, "");

	FileReaderOpen("arquivo.txt");
	FileReaderGetData(data);
	FileReaderClose();

	cout << "Imprimindo dado sem nenhum tratamento: " << data << endl;
	

	// Realizando as a��es com o tratamento convencional

	strcpy(data, "");
	int errorNumber;

	errorNumber = FileReaderOpen("arquivo.txt");
	if (errorNumber == 0)
	{
		errorNumber = FileReaderGetData(data);
		if (errorNumber == 0)
		{
			errorNumber = FileReaderClose();
			if (errorNumber == 0)
			{
				cout << "Imprimindo dado com tratamento convencional: " << data << endl;
			}
			else
			{
				cout << "Erro: " << errorNumber << endl;
			}
		}
		else
		{
			cout << "Erro: " << errorNumber << endl;
		}
	}
	else
	{
		cout << "Erro: " << errorNumber << endl;
	}


	// Realizando as a��es com o tratamento por exceptions

	strcpy(data, "");

	//EX_FileReaderOpen("arquivo.txt");
	//EX_FileReaderGetData(data);
	//EX_FileReaderClose();

	try
	{
		EX_FileReaderOpen("arquivo.txt");
		EX_FileReaderGetData(data);
		EX_FileReaderClose();

		cout << "Imprimindo dado com tratamento via exception: " << data << endl;
	}
	catch (int errorEx)
	{
		cout << "Erro (ex): " << errorEx << endl;
	}


	// Tratamento m�ltiplo de diferentes tipos de exceptions
	try
	{
		EX_DiferentThrowSample();
	}
	catch (int i)
	{
		cout << "Exception lancada: (int) " << i << endl;
	}
	catch (float f)
	{
		cout << "Exception lancada: (float) " << f << endl;
	}
	catch (char c)
	{
		cout << "Exception lancada: (char) " << c << endl;
	}
	catch (...)
	{
		cout << "Exception lancada mas nao especificada" << endl;
	}



	// Tratamento com classe customizada de exception
	try
	{
		EX_FuncaoLancaExceptionClass();
	}
	catch (MinhaException &me)
	{
		me.mensagemDeErro();
	}




	cout << endl;
	system("PAUSE");
	return 0;
}

