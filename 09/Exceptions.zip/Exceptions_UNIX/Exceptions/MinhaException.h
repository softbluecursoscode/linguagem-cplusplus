#pragma once

class MinhaException
{
public:
	int codigo;
	int porta;
	char servidor[30];

	MinhaException(int codigo, int porta, const char * servidor);
	void mensagemDeErro();
};