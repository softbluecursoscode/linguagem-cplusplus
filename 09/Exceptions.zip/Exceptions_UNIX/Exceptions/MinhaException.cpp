#include "MinhaException.h"

#include <iostream>
using namespace std;

MinhaException::MinhaException(int codigo, int porta, const char * servidor)
{
	this->codigo = codigo;
	this->porta = porta;
	strcpy(this->servidor, servidor);
}

void MinhaException::mensagemDeErro()
{
	cout << "Erro " << this->codigo << " ocorreu na porta " << this->porta;
	cout << " do servidor " << this->servidor << endl;
}