#include <iostream>
#include <queue>
#include <stack>
using namespace std;

int main()
{
	cout << "\nResolucao Exercicio 2 (NAMESPACES)\n\n";

	int opcao;
	int elemento;

	stack<int> minhaPilha;
	queue<int> minhaFila;

	do
	{
		cout << "\nDigite 1 para inserir, 2 para visualizar, 3 para processar e 4 para sair: ";
		cin >> opcao;

		switch (opcao)
		{
		case 1:
			cout << "\nDigite o elemento a ser inserido: ";
			cin >> elemento;

			minhaPilha.push(elemento);
			minhaFila.push(elemento);

			break;

		case 2:
			cout << "\nVisualizando: ";

			if (minhaPilha.size() > 0)
			{
				cout << "\n\tTamanho da pilha: " << minhaPilha.size();
				cout << "\n\tTamanho da fila: " << minhaFila.size();

				cout << "\n\tProximo elemento pilha: " << minhaPilha.top();
				cout << "\n\tProximo elemento fila: " << minhaFila.front();
			}
			else
			{
				cout << "\nAs estruturas estao vazias.";
			}
			break;

		case 3:
			cout << "\nProcessando: ";

			if (minhaPilha.size() > 0)
			{
				cout << "\n\tProcessando elemento na pilha: " << minhaPilha.top();
				minhaPilha.pop();

				cout << "\n\tProcessando elemento na fila: " << minhaFila.front();
				minhaFila.pop();
			}
			else
			{
				cout << "\nAs estruturas estao vazias.";
			}

			break;

		case 4:
			break;

		default:
			cout << "\nOpcao invalida.";
			break;
		}
	} while (opcao != 4);



	cout << endl;
	system("PAUSE");
	return 0;
}

