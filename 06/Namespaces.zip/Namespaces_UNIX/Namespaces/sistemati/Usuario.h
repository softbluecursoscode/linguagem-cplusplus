#pragma once

// Sistema TI

namespace sistemati
{
	class Usuario
	{
	public:
		char nome[20];
		char linguagemDominante[50];
	};
}

