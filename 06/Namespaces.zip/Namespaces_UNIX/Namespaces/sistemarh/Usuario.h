#pragma once

// Sistema RH

namespace sistemarh
{
	class Usuario
	{
	public:
		int idade;
		int horasTrabalhadas;
	};
}

