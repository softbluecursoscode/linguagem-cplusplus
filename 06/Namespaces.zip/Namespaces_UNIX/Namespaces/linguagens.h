#pragma once

namespace sistemati
{
	namespace linguagens
	{
		class Php
		{
		public:
			char nomeDoServidor[25];
		};

		class C
		{
		public:
			char plataforma[30];
		};
	}
}
